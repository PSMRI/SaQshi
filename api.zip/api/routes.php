return [

    'GET' => [
        '/assessment/v1/concerns' => [
            'controller' => 'AssessmentController',
            'method' => 'getConcerns'
        ],
        '/assessment/v1/standards' => [
            'controller' => 'AssessmentController',
            'method' => 'getStandards'
        ],
        '/assessment/v1/checklist' => [
            'controller' => 'AssessmentController',
            'method' => 'getChecklist'
        ],
    ],

    'POST' => [
        '/assessment/v1/response/save' => [
            'controller' => 'AssessmentController',
            'method' => 'saveResponse'
        ],
    ],

];